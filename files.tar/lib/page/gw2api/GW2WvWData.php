<?php
include_once './GW2ApiInterface.php';
/**
 * Adds a page with the view over the current WvW-Stats.
 *
 * @author		Yavis <administrator@asguardian.de>
 * @copyright	2013 Sebastian Loehr
 * @license		GNU Lesser General Public License <http://www.gnu.org/licenses/lgpl.html>
 * @package		de.asguardian.gw2.api
 * @version 0.4.0
 * @since 01.11.2013
 */
class GW2WvWData extends GW2ApiInterface {
    /**
     * Calculate the part of the cake each Border get's.
     * @param Array $tiks
     * @return Array The parts of the cake in percent.
     */
    public function calculateWvWPointsRelation($tiks,$border) {
        $relations[$border]["Red"] = ($tiks[$border]["Red"]/($tiks[$border]["Red"]+$tiks[$border]["Green"]+$tiks[$border]["Blue"]))*100;
        $relations[$border]["Blue"] = ($tiks[$border]["Blue"]/($tiks[$border]["Red"]+$tiks[$border]["Green"]+$tiks[$border]["Blue"]))*100;
        $relations[$border]["Green"] = ($tiks[$border]["Green"]/($tiks[$border]["Red"]+$tiks[$border]["Green"]+$tiks[$border]["Blue"]))*100;
        return $relations;
    }
    /**
     * Get an order for the borders.
     * @param Array $tiks Holds the current tiks of each border.
     * @return Array Holds the position-Tag for each border.
     */
    public function figureOutBorderPosition($tiks) {
        if($tiks["Red"] > $tiks["Green"]) {
            if($tiks["Blue"] > $tiks["Red"]) {
                $position["Red"] = "second";
                $position["Blue"] = "first";
                $position["Green"] = "third";
            } else {
                $position["Red"] = "first";
                if($tiks["Blue"] > $tiks["Green"]) {
                    $position["Blue"] = "second";
                    $position["Green"] = "third";
                } else {
                    $position["Blue"] = "third";
                    $position["Green"] = "second";
                }
            }
        } else if ($tiks["Green"] > $tiks["Blue"]) {
            $position["Green"] = "first";
            if($tiks["Blue"] > $tiks["Red"]) {
                $position["Red"] = "third";
                $position["Blue"] = "second";
            } else {
                $position["Red"] = "second";
                $position["Blue"] = "third";
            }
        } else {
            $position["Red"] = "third";
            $position["Blue"] = "first";
            $position["Green"] = "second";
        }
        return $position;
    }
    public function getBorderData($worldid, $border) {
        $match = parent::getWvWMatch($worldid);
        $match["points"] = parent::getWvWMatchPoints($match["wvw_match_id"]);
        $match["position"][$border] = $this->figureOutBorderPosition($match["points"][$border]);
        if ($border != "scores") {
            $match["relations"] = $this->calculateWvWPointsRelation($match["points"], $border);
        }
        $return["api_data"] = $match;
        return json_encode($return);
    }
    public function getMatchWorldsNames ($worldid, $language) {
        $match = parent::getWvWMatch($worldid);
        $worlds[] = $match["red_world_id"];
        $worlds[] = $match["blue_world_id"];
        $worlds[] = $match["green_world_id"];
        $worldnames = parent::getWorldsNames($language, $worlds);
        $names["Red"] = $worldnames[0];
        $names["Blue"] = $worldnames[1];
        $names["Green"] = $worldnames[2];
        $return["names"] = $names;
        return json_encode($return);
    }
}
$api = new GW2ApiInterface;
$wvw = new GW2WvWData;
$worldid = $_GET['world'];
$language = $_GET['lang'];
$border = $_GET['border'];
$modus = $_GET['modus'];
if($modus == "names") {
    echo $wvw->getMatchWorldsNames($worldid, $language);
}  else if($modus == "border") {
    echo $wvw->getBorderData($worldid, $border);
}
