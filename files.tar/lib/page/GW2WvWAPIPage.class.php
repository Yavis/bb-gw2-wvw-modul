<?php
// wcf import
require_once(WCF_DIR.'lib/page/AbstractPage.class.php');
require_once(WCF_DIR.'lib/page/util/menu/PageMenu.class.php');

/**
 *
 * @author    yavis
 * @copyright    2013 Sebastian Löhr
 * @package    de.asguaedian.gw2.wvw
 */
class GW2WvWAPIPage extends AbstractPage {
    // this is the part for the Template
    public $templateName = 'GW2WvWAPI';
    
    /**
    * @see Page::show()
    */
    public function show() {
        // set active PageMenu item
        PageMenu::setActiveMenuItem('wcf.header.menu.pageMenuItem36');
        
        parent::show();
    }
}
?>