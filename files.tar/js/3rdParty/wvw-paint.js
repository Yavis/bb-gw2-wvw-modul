/**
 * Adds the WvW - Functions of the api.
 * <p>
 * Here are all functions defined to use and paint the Data, 
 * the api gets about the wvw.
 * </p>
 *
 * @author		Yavis <administrator@asguardian.de>
 * @copyright	2013 Sebastian Loehr
 * @license		GNU Lesser General Public License <http://www.gnu.org/licenses/lgpl.html>
 * @package		de.asguardian.gw2.wvw
 * @version 0.5.4 Beta
 * @since 23.10.2013
 */
$("document").ready(function() {

/** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** 1st Part ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **
 * First part includes the functions, variables and Co. used for the Data-Part of the Plugin.
 ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
    var worldid = document.getElementById('worldid').textContent;
    var updatetime = document.getElementById('updatetime').textContent;
    var language = document.getElementById('lang').textContent;
    
    var matchEndTimestamp;
    var newBordernames = false;
    var matchdata;
    var matchinfos;
    var WvWObjects;
    WvWObjects = getWvWObjects(language);
    actualiseMatchData(worldid, true);
    
    function actualiseMatchData(worldid, setup) {
        var matchid = 0;
        if(!setup) {
            matchid = matchdata["wvw_match_id"];
        }
        matchdata = getWvWMatch(worldid);
        if (matchid !== matchdata["wvw_match_id"]){
            newBordernames = true;
        }
    }
    function initialise() {
        matchinfos = [];
        matchinfos = getData("https://api.guildwars2.com/v1/wvw/match_details.json?match_id="+matchdata["wvw_match_id"]);
        newBordernames = true;
    }
    function updateDatas() {
        var now = new Date();
        now = Math.round(now.getTime() / 1000);
        var resttime = (matchEndTimestamp-now);
        console.log("Time left in this match: "+resttime+"s.");
        if(resttime < -3600) {
            actualiseMatchData(worldid, false);
            newmatch();
        } else if(resttime < 0) {
            actualiseMatchData(worldid, false);
            newmatch();
            newBordernames = true;
        }
        matchinfos = [];
        matchinfos = getData("https://api.guildwars2.com/v1/wvw/match_details.json?match_id="+matchdata["wvw_match_id"]);
        paint();
        setMarkersHolder();
    }
    
    /**
 * Calculating the Points each Border made on an Borderland.
 * @param Array mapsobjects
 * @param Array WvWObjects Objects to get the names of. (getWvWObjects("de"))
 * @return int
 */
function calculateWvWMapPoints(mapsobjects) {
    var mappoint = [];
    mappoint["Red"] = 0;
    mappoint["Blue"] = 0;
    mappoint["Green"] = 0;
    mappoint["Neutral"] = 0;
    var addpoints = 0;
    for(var i = 0;i < mapsobjects.length; i++) {
            switch (mapsobjects[i].id) {
                case 9:
                    addpoints = 35;
                    break;
                    //RedHome Feste:
                case 32:
                case 33:
                case 37:
                    //GreenHome Feste:
                case 41:
                case 44:
                case 46:
                    //BlueHome Feste:
                case 23:  
                case 27:
                case 31:
                    //Center Feste:
                case 1:
                case 2:
                case 3:
                    addpoints = 25;
                    break;
                //RedHome Turm:
                case 35:
                case 36:
                case 38:
                case 40:
                //GreenHome Turm:
                case 42:
                case 45:
                case 47:
                case 57:
                //BlueHome Turm:
                case 25:
                case 26:
                case 28:
                case 30:
                //Center Turm
                case 11:
                case 12:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                    addpoints = 10;
                    break;
                //RedHome Lager:
                case 34:
                case 39:
                case 50:
                case 51:
                case 52:
                case 53:
                //GreenHome Turm:
                case 43:
                case 48:
                case 49:
                case 54:
                case 55:
                case 56:
                //BlueHome Turm:
                case 24:
                case 29:
                case 58:
                case 59:
                case 60:
                case 61:
                //Center Turm:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 10:
                    addpoints = 5;
                    break;
                default:
                    addpoints = 0;
                    break;
            }
            mappoint[mapsobjects[i].owner] += addpoints;
        }
        return mappoint;
    }
    /**
     * Get the points of an WvW-Match, using the matchid.
     * @param int matchid
     * @return Array All scores and tiks.
     */
    function getWvWMatchPoints() {
        var tiks = [];
        var bonuses = [];
        bonuses.Red = 0;
        bonuses.Green = 0;
        bonuses.Blue = 0;
        tiks.All = [];
        tiks.RedHome = [];
        tiks.GreenHome = [];
        tiks.BlueHome = [];
        tiks.Center = [];
        tiks.scores = [];
        tiks.scores.Red = matchinfos["scores"][0];
        tiks.scores.Blue = matchinfos["scores"][1];
        tiks.scores.Green = matchinfos["scores"][2];
        for(var i = 0; i < 4; i++) {
            tiks[matchinfos.maps[i].type] = calculateWvWMapPoints(matchinfos.maps[i].objectives);
            if(i < 3) {
                bonuses[matchinfos.maps[i].bonuses[0].owner] += 1;
            }
        }
        $("#gw2-wvw > #wvw-scores > #score > #red_score > span.bloodlust").width(bonuses.Red * 20);
        $("#gw2-wvw > #wvw-scores > #score > #blue_score > span.bloodlust").width(bonuses.Blue * 20);
        $("#gw2-wvw > #wvw-scores > #score > #green_score > span.bloodlust").width(bonuses.Green * 20);
        tiks.All.Red = tiks["RedHome"]["Red"] + tiks["GreenHome"]["Red"] + tiks["BlueHome"]["Red"] + tiks["Center"]["Red"];
        tiks.All.Blue = tiks["RedHome"]["Blue"] + tiks["GreenHome"]["Blue"] + tiks["BlueHome"]["Blue"] + tiks["Center"]["Blue"];
        tiks.All.Green = tiks["RedHome"]["Green"] + tiks["GreenHome"]["Green"] + tiks["BlueHome"]["Green"] + tiks["Center"]["Green"];
        return tiks;
    }
     /**
     * Calculate the part of the cake each Border get's.
     * @param Array tiks
     * @return Array The parts of the cake in percent.
     */
    function calculateWvWPointsRelation(tiks,border) {
        var relations = [];
        relations[border] = [];
        relations[border]["Red"] = (tiks[border]["Red"]/(tiks[border]["Red"]+tiks[border]["Green"]+tiks[border]["Blue"]))*100;
        relations[border]["Blue"] = (tiks[border]["Blue"]/(tiks[border]["Red"]+tiks[border]["Green"]+tiks[border]["Blue"]))*100;
        relations[border]["Green"] = (tiks[border]["Green"]/(tiks[border]["Red"]+tiks[border]["Green"]+tiks[border]["Blue"]))*100;
        return relations;
    }
    /**
     * Get an order for the borders.
     * @param Array tiks Holds the current tiks of each border.
     * @return Array Holds the position-Tag for each border.
     */
    function figureOutBorderPosition(tiks) {
        var position = [];
        if(tiks["Red"] > tiks["Green"]) {
            if(tiks["Blue"] > tiks["Red"]) {
                position["Red"] = "second";
                position["Blue"] = "first";
                position["Green"] = "third";
            } else {
                position["Red"] = "first";
                if(tiks["Blue"] > tiks["Green"]) {
                    position["Blue"] = "second";
                    position["Green"] = "third";
                } else {
                    position["Blue"] = "third";
                    position["Green"] = "second";
                }
            }
        } else if (tiks["Green"] > tiks["Blue"]) {
            position["Green"] = "first";
            if(tiks["Blue"] > tiks["Red"]) {
                position["Red"] = "third";
                position["Blue"] = "second";
            } else {
                position["Red"] = "second";
                position["Blue"] = "third";
            }
        } else {
            position["Red"] = "third";
            position["Blue"] = "first";
            position["Green"] = "second";
        }
        return position;
    }
    function getBorderData(border) {
        var match = [];
        match = matchdata;
        match["points"] = getWvWMatchPoints(matchdata["wvw_match_id"]);
        match.position = [];
        match.position[border] = figureOutBorderPosition(matchdata["points"][border]);
        if (border != "scores") {
            match["relations"] = calculateWvWPointsRelation(matchdata["points"], border);
        }
        return match;
    }
    function getMatchWorldsNames (language) {
        var worlds = [], names = [];
        worlds[0] = matchdata["red_world_id"];
        worlds[1] = matchdata["blue_world_id"];
        worlds[2] = matchdata["green_world_id"];
        var worldnames = getWorldsNames(language, worlds);
        names["Red"] = worldnames[0];
        names["Blue"] = worldnames[1];
        names["Green"] = worldnames[2];
        return names;
    }
/**
 * Function to paint the diagram into the canvas-Container
 * <p>
 * This functions paints the diagram-data into an canvas-container with an defined containerstring as id.
 * </p>
 * @param {String} Containerstring Id-Tag of the Canvas-Container in which the diagram shall be painted.
 * @param {Array} relations JSON-Array witch holds the relations of the Border, which are owned by each color.
 * @param {Array} worldnames Array that holds the names of the worlds. (Not needed yet, just for later)
 * @returns nothing, paints and dies.
 */
 function WvWCanvas(Containerstring, relations) {
     /**
      * Using Kinectic here
      */
     var stage = new Kinetic.Stage({
        container: 'WvW-Diagram',
        width: 280,
        height: 280
      });
     var layer = new Kinetic.Layer();
     var red = new Kinetic.Wedge({
        x: 140,
        y: 140,
        radius: 120,
        angleDeg: 3.6*relations.Red,
        fill: '#D74C47',
        stroke: 'white',
        strokeWidth: 1,
        rotationDeg: -90
      });
      red.on('mouseover', function(e) {
          $("div#red-diagram").css({
             left: e.pageX,
             top: e.pageY});
          $("div#red-diagram").fadeIn(0);
          this.setFill('#E85d58');
          layer.draw();
      });
      red.on('mouseout', function() {
          $("div#red-diagram").fadeOut(0);
          this.setFill('#D74C47');
          layer.draw();
      });
      // add the shape to the layer
      layer.add(red);

      var green = new Kinetic.Wedge({
        x: 140,
        y: 140,
        radius: 120,
        angleDeg: 3.6*relations.Green,
        fill: '#5DB75D',
        stroke: 'white',
        strokeWidth: 1,
        rotationDeg: (3.6*relations.Red)-90
      });
      green.on('mouseover', function(e) {
         $("div#green-diagram").css({
             left: e.pageX,
             top: e.pageY});
          $("div#green-diagram").fadeIn(0);
          this.setFill('#6EC86E');
          layer.draw();
      });
      green.on('mouseout', function() {
          $("div#green-diagram").fadeOut(0);
          this.setFill('#5DB75D');
          layer.draw();
      });
      // add the shape to the layer
      layer.add(green);

      var blue = new Kinetic.Wedge({
        x: 140,
        y: 140,
        radius: 120,
        angleDeg: 3.6*relations.Blue,
        fill: '#0E8FD1',
        stroke: 'white',
        strokeWidth: 1,
        rotationDeg: ((relations.Red+relations.Green)*3.6)-90
      });
      blue.on('mouseover', function(e) {
         $("div#blue-diagram").css({
             left: e.pageX,
             top: e.pageY});
          $("div#blue-diagram").fadeIn(0);
          this.setFill('#1F9FE2');
          layer.draw();
      });
      blue.on('mouseout', function() {
          $("div#blue-diagram").fadeOut(0);
          this.setFill('#0E8FD1');
          layer.draw();
      });
      // add the shape to the layer
      layer.add(blue);

      // add the layer to the stage
      stage.add(layer);
     
    return 0;
}
/**
 * Function to paint the data into the tempalte.
 * @returns nothing Paints the data and dies.
 */
function paint() {
    var points, position, relation;
    var border = $("#wvw-navigation > div.active").attr("id");
    var dataToPaint = getBorderData(border);
    if(border == "All") {
        points = dataToPaint.points.All;
        position = dataToPaint.position.All;
        relation = dataToPaint.relations.All;
    } else if(border == "RedHome") {
        points = dataToPaint.points.RedHome;
        position = dataToPaint.position.RedHome;
        relation = dataToPaint.relations.RedHome;
    } else if(border == "BlueHome") {
        points = dataToPaint.points.BlueHome;
        position = dataToPaint.position.BlueHome;
        relation = dataToPaint.relations.BlueHome;
    } else if(border == "GreenHome") {
        points = dataToPaint.points.GreenHome;
        position = dataToPaint.position.GreenHome;
        relation = dataToPaint.relations.GreenHome;
    } else if(border == "Center") {
        points = dataToPaint.points.Center;
        position = dataToPaint.position.Center;
        relation = dataToPaint.relations.Center;
    }
    paintBorderstats(points, position);
    WvWCanvas("WvW-Diagram", relation);
    return 0;
}

function paintBorderstats(points, position) {
    $("#red-diagram > .red_score_2ndline > .red_score_over").text(points.Red);
    $("#blue-diagram > .blue_score_2ndline > .blue_score_over").text(points.Blue);
    $("#green-diagram > .green_score_2ndline > .green_score_over").text(points.Green);
    $("#wvw-data > #WvW-Tiks > div > #tik.red > .red_tik").text(points.Red);
    $("#wvw-data > #WvW-Tiks > div > #tik.blue > .blue_tik").text(points.Blue);
    $("#wvw-data > #WvW-Tiks > div > #tik.green > .green_tik").text(points.Green);
    $("#wvw-data > #WvW-Tiks > div > #tik.red").appendTo("#wvw-data > #WvW-Tiks > ."+position.Red);
    $("#wvw-data > #WvW-Tiks > div > #tik.blue").appendTo("#wvw-data > #WvW-Tiks > ."+position.Blue);
    $("#wvw-data > #WvW-Tiks > div > #tik.green").appendTo("#wvw-data > #WvW-Tiks > ."+position.Green);
}

function setBorderNames() {
    var names = getMatchWorldsNames(language);
    var bordername = "";
    if (names.Red != null) {
        bordername = names.Red;
        bordername = bordername.replace(" [DE]", "");
        bordername = bordername.replace(" [FR]", "");
        $("#RedHome").text(bordername);
        $(".red_tik_name").text(bordername);
        $(".red_score_name_over").text(bordername);
        $(".red_score_name").text(bordername);
    }
    if (names.Blue != null) {
        bordername = names.Blue;
        bordername = bordername.replace("[DE]", "");
        bordername = bordername.replace("[FR]", "");
        $("#BlueHome").text(bordername);
        $(".blue_tik_name").text(bordername);
        $(".blue_score_name_over").text(bordername);
        $(".blue_score_name").text(bordername);
    }
    if (names.Green != null) {
        bordername = names.Green;
        bordername = bordername.replace("[DE]", "");
        bordername = bordername.replace("[FR]", "");
        $("#GreenHome").text(bordername);
        $(".green_tik_name").text(bordername);
        $(".green_score_name_over").text(bordername);
        $(".green_score_name").text(bordername);
    } 
}

function setScores() {
    var scores = getBorderData("scores");
    $(".red_score").text(scores.points.scores.Red);
    $(".green_score").text(scores.points.scores.Green);
    $(".blue_score").text(scores.points.scores.Blue);
    $("#red_score").appendTo("#wvw-scores > #score."+scores.position.scores.Red);
    $("#green_score").appendTo("#wvw-scores > #score."+scores.position.scores.Green);
    $("#blue_score").appendTo("#wvw-scores > #score."+scores.position.scores.Blue);
}

function eventlistener() {
    $(".tab").click(function () {
        $('div#wvw-data').fadeOut();
        $("div#gw2-wvw > div#wvw-navigation > div.active").removeClass("active");
        $(this).addClass("active");
        paint();
        $('div#wvw-data').fadeIn();
    });
}







var map;
/**
 * Holds the Informations for each Markes for setup
 * @type Array|@arr;markers
 */
var markers;
/**
 * Holds the marker objects of the map.
 * @type @new;L.marker@call;addTo
 */
var marker;
/**
 * Array that holds owners for each marker.
 * @type [String]
 */
var owner;
// Set up the icons
var greyCastle = L.icon({
    iconUrl: '../wcf/images/gw2api/castle_neutral.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redCastle = L.icon({
    iconUrl: '../wcf/images/gw2api/castle_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenCastle = L.icon({
    iconUrl: '../wcf/images/gw2api/castle_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueCastle = L.icon({
    iconUrl: '../wcf/images/gw2api/castle_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greyBastion = L.icon({
    iconUrl: '../wcf/images/gw2api/bastion_neutral.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redBastion = L.icon({
    iconUrl: '../wcf/images/gw2api/bastion_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenBastion = L.icon({
    iconUrl: '../wcf/images/gw2api/bastion_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueBastion = L.icon({
    iconUrl: '../wcf/images/gw2api/bastion_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greyTower = L.icon({
    iconUrl: '../wcf/images/gw2api/tower_neutral.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redTower = L.icon({
    iconUrl: '../wcf/images/gw2api/tower_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenTower = L.icon({
    iconUrl: '../wcf/images/gw2api/tower_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueTower = L.icon({
    iconUrl: '../wcf/images/gw2api/tower_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greyCamp = L.icon({
    iconUrl: '../wcf/images/gw2api/camp_neutral.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redCamp = L.icon({
    iconUrl: '../wcf/images/gw2api/camp_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenCamp = L.icon({
    iconUrl: '../wcf/images/gw2api/camp_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueCamp = L.icon({
    iconUrl: '../wcf/images/gw2api/camp_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redCastleOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/castle_red_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenCastleOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/castle_green_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueCastleOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/castle_blue_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redBastionOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/bastion_red_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenBastionOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/bastion_green_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueBastionOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/bastion_blue_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redTowerOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/tower_red_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenTowerOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/tower_green_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueTowerOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/tower_blue_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redCampOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/camp_red_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenCampOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/camp_green_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueCampOwned = L.icon({
    iconUrl: '../wcf/images/gw2api/camp_blue_owned.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var whiteTemple = L.icon({
    iconUrl: '../wcf/images/gw2api/temple_of_lost_prayers_white.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redTemple = L.icon({
    iconUrl: '../wcf/images/gw2api/temple_of_lost_prayers_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenTemple = L.icon({
    iconUrl: '../wcf/images/gw2api/temple_of_lost_prayers_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueTemple = L.icon({
    iconUrl: '../wcf/images/gw2api/temple_of_lost_prayers_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var whiteHollow = L.icon({
    iconUrl: '../wcf/images/gw2api/battles_hollow_white.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redHollow = L.icon({
    iconUrl: '../wcf/images/gw2api/battles_hollow_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenHollow = L.icon({
    iconUrl: '../wcf/images/gw2api/battles_hollow_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueHollow = L.icon({
    iconUrl: '../wcf/images/gw2api/battles_hollow_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var whiteBauer = L.icon({
    iconUrl: '../wcf/images/gw2api/bauers_estate_white.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redBauer = L.icon({
    iconUrl: '../wcf/images/gw2api/bauers_estate_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenBauer = L.icon({
    iconUrl: '../wcf/images/gw2api/bauers_estate_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueBauer = L.icon({
    iconUrl: '../wcf/images/gw2api/bauers_estate_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var whiteOrchard = L.icon({
    iconUrl: '../wcf/images/gw2api/orchard_overlook_white.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redOrchard = L.icon({
    iconUrl: '../wcf/images/gw2api/orchard_overlook_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenOrchard = L.icon({
    iconUrl: '../wcf/images/gw2api/orchard_overlook_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueOrchard = L.icon({
    iconUrl: '../wcf/images/gw2api/orchard_overlook_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var whiteCarver = L.icon({
    iconUrl: '../wcf/images/gw2api/carvers_ascent_white.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var redCarver = L.icon({
    iconUrl: '../wcf/images/gw2api/carvers_ascent_red.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var greenCarver = L.icon({
    iconUrl: '../wcf/images/gw2api/carvers_ascent_green.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});
var blueCarver = L.icon({
    iconUrl: '../wcf/images/gw2api/carvers_ascent_blue.png',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, 0]
});


function setMapMarkers() {
    markers = [];
    markers[0] = [];
    markers[0].name = "Unseen";
    markers[0].icon = greyCamp;
    markers[0].coord = new Array(0, 0);
    owner = [];
    for(var j = 0; j < 4; j++) {
        var mapobjects = matchinfos.maps[j].objectives;
        for(var i=0; i < mapobjects.length; i++) {
            var id = mapobjects[i].id;
            owner[id] = [];
            owner[id].owner = "Grey";
            owner[id].guild = "0";
            markers[id] = [];
            markers[id].name = (searchWvWObject(WvWObjects, mapobjects[i].id)).name;
            switch (id) {
                    //Schloss
                    case 9:
                        markers[id].coord = new Array(10582, 14617);
                        markers[id].icon = greyCastle;
                        break;
                    //RedHome Feste:
                    case 32:
                        markers[id].coord = new Array(11656, 10976);
                        markers[id].icon = greyBastion;
                        break;
                    case 33:
                        markers[id].coord = new Array(9436, 11058);
                        markers[id].icon = greyBastion;
                        break;
                    case 37:
                        markers[id].coord = new Array(10459, 10532);
                        markers[id].icon = greyBastion;
                        break;
                    //GreenHome Feste:
                    case 41:
                        markers[id].coord = new Array(8064, 13544);
                        markers[id].icon = greyBastion;
                        break;
                    case 44:
                        markers[id].coord = new Array(5839, 13626);
                        markers[id].icon = greyBastion;
                        break;
                    case 46:
                        markers[id].coord = new Array(6880, 13090);
                        markers[id].icon = greyBastion;
                        break;
                    //BlueHome Feste:
                    case 23:
                        markers[id].coord = new Array(14042, 12452);
                        markers[id].icon = greyBastion;
                        break;  
                    case 27:
                        markers[id].coord = new Array(13021, 12977);
                        markers[id].icon = greyBastion;
                        break;
                    case 31:
                        markers[id].coord = new Array(15237, 12901);
                        markers[id].icon = greyBastion;
                        break;
                    //Center Feste:
                    case 1:
                        markers[id].coord = new Array(10752, 13672);
                        markers[id].icon = greyBastion;
                        break;
                    case 2:
                        markers[id].coord = new Array(11474, 15137);
                        markers[id].icon = greyBastion;
                        break;
                    case 3:
                        markers[id].coord = new Array(9589, 15147);
                        markers[id].icon = greyBastion;
                        break;
                    //RedHome Turm:
                    case 35:
                        markers[id].coord = new Array(10076, 11439);
                        markers[id].icon = greyTower;
                        break;
                    case 36:
                        markers[id].coord = new Array(10985, 11439);
                        markers[id].icon = greyTower;
                        break;
                    case 38:
                        markers[id].coord = new Array(9850, 10177);
                        markers[id].icon = greyTower;
                        break;
                    case 40:
                        markers[id].coord = new Array(11083, 10177);
                        markers[id].icon = greyTower;
                        break;
                    //GreenHome Turm:
                    case 42:
                        markers[id].coord = new Array(7389, 14001);
                        markers[id].icon = greyTower;
                        break;
                    case 45:
                        markers[id].coord = new Array(6493, 14001);
                        markers[id].icon = greyTower;
                        break;
                    case 47:
                        markers[id].coord = new Array(6268, 12735);
                        markers[id].icon = greyTower;
                        break;
                    case 57:
                        markers[id].coord = new Array(7503, 12735);
                        markers[id].icon = greyTower;
                        break;
                    //BlueHome Turm:
                    case 25:
                        markers[id].coord = new Array(13666, 13359);
                        markers[id].icon = greyTower;
                        break;
                    case 26:
                        markers[id].coord = new Array(14567, 13359);
                        markers[id].icon = greyTower;
                        break;
                    case 28:
                        markers[id].coord = new Array(14671, 12051);
                        markers[id].icon = greyTower;
                        break;
                    case 30:
                        markers[id].coord = new Array(13434, 12051);
                        markers[id].icon = greyTower;
                        break;
                    //Center Turm
                    case 11:
                        markers[id].coord = new Array(9404, 14808);
                        markers[id].icon = greyTower;
                        break;
                    case 12:
                        markers[id].coord = new Array(9889, 14639);
                        markers[id].icon = greyTower;
                        break;
                    case 13:
                        markers[id].coord = new Array(9795, 15422);
                        markers[id].icon = greyTower;
                        break;
                    case 14:
                        markers[id].coord = new Array(10165, 15094);
                        markers[id].icon = greyTower;
                        break;
                    case 15:
                        markers[id].coord = new Array(11444, 15505);
                        markers[id].icon = greyTower;
                        break;
                    case 16:
                        markers[id].coord = new Array(10840, 15238);
                        markers[id].icon = greyTower;
                        break;
                    case 17:
                        markers[id].coord = new Array(10249, 13529);
                        markers[id].icon = greyTower;
                        break;
                    case 18:
                        markers[id].coord = new Array(10176, 14099);
                        markers[id].icon = greyTower;
                        break;
                    case 19:
                        markers[id].coord = new Array(10996, 13869);
                        markers[id].icon = greyTower;
                        break;
                    case 20:
                        markers[id].coord = new Array(11082, 13501);
                        markers[id].icon = greyTower;
                        break;
                    case 21:
                        markers[id].coord = new Array(11146, 14544);
                        markers[id].icon = greyTower;
                        break;
                    case 22:
                        markers[id].coord = new Array(11753, 14809);
                        markers[id].icon = greyTower;
                        break;
                    //RedHome Lager:
                    case 34:
                        markers[id].coord = new Array(10487, 12137);
                        markers[id].icon = greyCamp;
                        break;
                    case 39:
                        markers[id].coord = new Array(10487, 9327);
                        markers[id].icon = greyCamp;
                        break;
                    case 50:
                        markers[id].coord = new Array(11418, 11593);
                        markers[id].icon = greyCamp;
                        break;
                    case 51:
                        markers[id].coord = new Array(11418, 10251);
                        markers[id].icon = greyCamp;
                        break;
                    case 52:
                        markers[id].coord = new Array(9605, 10251);
                        markers[id].icon = greyCamp;
                        break;
                    case 53:
                        markers[id].coord = new Array(9666, 11593);
                        markers[id].icon = greyCamp;
                        break;
                    //GreenHome Lager:
                    case 43:
                        //SL
                        markers[id].coord = new Array(6897, 14680);
                        markers[id].icon = greyCamp;
                        break;
                    case 48:
                        //WL
                        markers[id].coord = new Array(6017, 12807);
                        markers[id].icon = greyCamp;
                        break;
                    case 49:
                        //SWL
                        markers[id].coord = new Array(6087, 14116);
                        markers[id].icon = greyCamp;
                        break;
                    case 54:
                        //OL
                        markers[id].coord = new Array(7859, 12807);
                        markers[id].icon = greyCamp;
                        break;
                    case 55:
                        //SOL
                        markers[id].coord = new Array(7829, 14116);
                        markers[id].icon = greyCamp;
                        break;
                    case 56:
                        //NL
                        markers[id].coord = new Array(6912, 11877);
                        markers[id].icon = greyCamp;
                        break;
                    //BlueHome Lager:
                    case 24:
                        //SL
                        markers[id].coord = new Array(14068, 14052);
                        markers[id].icon = greyCamp;
                        break;
                    case 29:
                        //NL
                        markers[id].coord = new Array(14081, 11231);
                        markers[id].icon = greyCamp;
                        break;
                    case 58:
                        //WL
                        markers[id].coord = new Array(13193, 12230);
                        markers[id].icon = greyCamp;
                        break;
                    case 59:
                        //SWL
                        markers[id].coord = new Array(13260, 13474);
                        markers[id].icon = greyCamp;
                        break;
                    case 60:
                        //OL
                        markers[id].coord = new Array(15030, 12230);
                        markers[id].icon = greyCamp;
                        break;
                    case 61:
                        //SOL
                        markers[id].coord = new Array(15030, 13474);
                        markers[id].icon = greyCamp;
                        break;
                    //Center Lager:
                    case 4:
                        //SWL / Golanta
                        markers[id].coord = new Array(10195, 15460);
                        markers[id].icon = greyCamp;
                        break;
                    case 5:
                        //NOL / Pangloss
                        markers[id].coord = new Array(11283, 13792);
                        markers[id].icon = greyCamp;
                        break;
                    case 6:
                        //NWL / Speldan
                        markers[id].coord = new Array(9781, 13560);
                        markers[id].icon = greyCamp;
                        break;
                    case 7:
                        //SOL / Danelon
                        markers[id].coord = new Array(11010, 15596);
                        markers[id].icon = greyCamp;
                        break;
                    case 8:
                        //OL / Umberlichtung
                        markers[id].coord = new Array(11562, 14472);
                        markers[id].icon = greyCamp;
                        break;
                    case 10:
                        //WL / Schurkenbruch
                        markers[id].coord = new Array(9619, 14434);
                        markers[id].icon = greyCamp;
                        break;
                    case 62:
                        // Ruine Mitte
                        markers[id].coord = new Array(10483, 11423);
                        markers[id].icon = whiteTemple;
                        if (language == 'de') {
                            markers[id].name = "Tempel der vergebenen Gebete";
                        } else {
                            markers[id].name = "Temple of Lost Prayers";
                        }
                        break;
                    case 63:
                        // Ruine Mitte
                        markers[id].coord = new Array(10177, 11153);
                        markers[id].icon = whiteHollow;
                        if (language == 'de') {
                            markers[id].name = "Kampfkuhle";
                        } else {
                            markers[id].name = "Battle's Hollow";
                        }
                        break;
                    case 64:
                        // Ruine Mitte
                        markers[id].coord = new Array(10273, 10784);
                        markers[id].icon = whiteBauer;
                        if (language == 'de') {
                            markers[id].name = "Bauers Anwesen";
                        } else {
                            markers[id].name = "Bauer's Estate";
                        }
                        break;
                    case 65:
                        // Ruine Mitte
                        markers[id].coord = new Array(10743, 10838);
                        markers[id].icon = whiteOrchard;
                        if (language == 'de') {
                            markers[id].name = "Obstgarten-Aussichtspunkt";
                        } else {
                            markers[id].name = "Orchard Overlook";
                        }
                        break;
                    case 66:
                        // Ruine Mitte
                        markers[id].coord = new Array(10778, 11190);
                        markers[id].icon = whiteCarver;
                        if (language == 'de') {
                            markers[id].name = "Aufstieg des Schnitzers";
                        } else {
                            markers[id].name = "Carver's Ascent";
                        }
                        break;
                    case 67:
                        // Ruine Rechts
                        markers[id].coord = new Array(14364, 13108);
                        markers[id].icon = whiteCarver;
                        if (language == 'de') {
                            markers[id].name = "Aufstieg des Schnitzers";
                        } else {
                            markers[id].name = "Carver's Ascent";
                        }
                        break;
                    case 68:
                        // Ruine Rechts
                        markers[id].coord = new Array(14330, 12762);
                        markers[id].icon = whiteOrchard;
                        if (language == 'de') {
                            markers[id].name = "Obstgarten-Aussichtspunkt";
                        } else {
                            markers[id].name = "Orchard Overlook";
                        }
                        break;
                    case 69:
                        // Ruine Rechts
                        markers[id].coord = new Array(13855, 12703);
                        markers[id].icon = whiteBauer;
                        if (language == 'de') {
                            markers[id].name = "Bauers Anwesen";
                        } else {
                            markers[id].name = "Bauer's Estate";
                        }
                        break;
                    case 70:
                        // Ruine Rechts
                        markers[id].coord = new Array(13756, 13067);
                        markers[id].icon = whiteHollow;
                        if (language == 'de') {
                            markers[id].name = "Kampfkuhle";
                        } else {
                            markers[id].name = "Battle's Hollow";
                        }
                        break;
                    case 71:
                        // Ruine Rechts
                        markers[id].coord = new Array(14066, 13344);
                        markers[id].icon = whiteTemple;
                        if (language == 'de') {
                            markers[id].name = "Tempel der vergebenen Gebete";
                        } else {
                            markers[id].name = "Temple of Lost Prayers";
                        }
                        break;
                        break;
                    case 72:
                        // Ruine Links
                        markers[id].coord = new Array(7193, 13749);
                        markers[id].icon = whiteCarver;
                        if (language == 'de') {
                            markers[id].name = "Aufstieg des Schnitzers";
                        } else {
                            markers[id].name = "Carver's Ascent";
                        }
                        break;
                    case 73:
                        // Ruine Links
                        markers[id].coord = new Array(7161, 13398);
                        markers[id].icon = whiteOrchard;
                        if (language == 'de') {
                            markers[id].name = "Obstgarten-Aussichtspunkt";
                        } else {
                            markers[id].name = "Orchard Overlook";
                        }
                        break;
                    case 74:
                        // Ruine Links
                        markers[id].coord = new Array(6689, 13342);
                        markers[id].icon = whiteBauer;
                        if (language == 'de') {
                            markers[id].name = "Bauers Anwesen";
                        } else {
                            markers[id].name = "Bauer's Estate";
                        }
                        break;
                    case 75:
                        // Ruine Links
                        markers[id].coord = new Array(6588, 13709);
                        markers[id].icon = whiteHollow;
                        if (language == 'de') {
                            markers[id].name = "Kampfkuhle";
                        } else {
                            markers[id].name = "Battle's Hollow";
                        }
                        break;
                    case 76:
                        // Ruine Links
                        markers[id].coord = new Array(6896, 13980);
                        markers[id].icon = whiteTemple;
                        if (language == 'de') {
                            markers[id].name = "Tempel der vergebenen Gebete";
                        } else {
                            markers[id].name = "Temple of Lost Prayers";
                        }
                        break;
                        break;
                default:
                        markers[id].coord = new Array(0, 0);
                        markers[id].icon = greyCamp;
                        break;
            }
        }
    }
}

function setMarkersHolder() {
    for(var j = 0; j < 4; j++) {
        var mapobjects = matchinfos.maps[j].objectives;
        for(var i = 0; i < mapobjects.length; i++) {
            var id = mapobjects[i].id;
            if(mapobjects[i].owner_guild) {
                updateOwnerGuild(mapobjects[i].owner_guild, id);
            } else {
                updateOwner(mapobjects[i].owner, id);
            }
            switch (id) {
                    //Schloss
                    case 9:
                        if(mapobjects[i].owner === "Red") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = redCastleOwned;
                            } else {
                                markers[id].icon = redCastle;
                            }
                        } else if(mapobjects[i].owner === "Green") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = greenCastleOwned;
                            } else {
                                markers[id].icon = greenCastle;
                            }
                        } else if(mapobjects[i].owner === "Blue") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = blueCastleOwned;
                            } else {
                                markers[id].icon = blueCastle;
                            }
                        }
                        break;
                    //RedHome Feste:
                    case 32:
                    case 33:
                    case 37:
                    //GreenHome Feste:
                    case 41:
                    case 44:
                    case 46:
                    //BlueHome Feste:
                    case 23:  
                    case 27:
                    case 31:
                    //Center Feste:
                    case 1:
                    case 2:
                    case 3:
                        if(mapobjects[i].owner === "Red") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = redBastionOwned;
                            } else {
                                markers[id].icon = redBastion;
                            }
                        } else if(mapobjects[i].owner === "Green") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = greenBastionOwned;
                            } else {
                                markers[id].icon = greenBastion;
                            }
                        } else if(mapobjects[i].owner === "Blue") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = blueBastionOwned;
                            } else {
                                markers[id].icon = blueBastion;
                            }
                        }
                        break;
                    //RedHome Turm:
                    case 35:
                    case 36:
                    case 38:
                    case 40:
                    //GreenHome Turm:
                    case 42:
                    case 45:
                    case 47:
                    case 57:
                    //BlueHome Turm:
                    case 25:
                    case 26:
                    case 28:
                    case 30:
                    //Center Turm
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                    case 21:
                    case 22:
                        if(mapobjects[i].owner === "Red") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = redTowerOwned;
                            } else {
                                markers[id].icon = redTower;
                            }
                        } else if(mapobjects[i].owner === "Green") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = greenTowerOwned;
                            } else {
                                markers[id].icon = greenTower;
                            }
                        } else if(mapobjects[i].owner === "Blue") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = blueTowerOwned;
                            } else {
                                markers[id].icon = blueTower;
                            }
                        }
                        break;
                    //RedHome Lager:
                    case 34:
                    case 39:
                    case 50:
                    case 51:
                    case 52:
                    case 53:
                    //GreenHome Turm:
                    case 43:
                    case 48:
                    case 49:
                    case 54:
                    case 55:
                    case 56:
                    //BlueHome Turm:
                    case 24:
                    case 29:
                    case 58:
                    case 59:
                    case 60:
                    case 61:
                    //Center Turm:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 10:
                        if(mapobjects[i].owner === "Red") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = redCampOwned;
                            } else {
                                markers[id].icon = redCamp;
                            }
                        } else if(mapobjects[i].owner === "Green") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = greenCampOwned;
                            } else {
                                markers[id].icon = greenCamp;
                            }
                        } else if(mapobjects[i].owner === "Blue") {
                            if(mapobjects[i].owner_guild) {
                                markers[id].icon = blueCampOwned;
                            } else {
                                markers[id].icon = blueCamp;
                            }
                        }
                        break;
                    case 62:
                    case 71:
                    case 76:
                        if(mapobjects[i].owner === "Red") {
                            markers[id].icon = redTemple;
                        } else if(mapobjects[i].owner === "Green") {
                            markers[id].icon = greenTemple;
                        } else if(mapobjects[i].owner === "Blue") {
                            markers[id].icon = blueTemple;
                        } else {
                            markers[id].icon = whiteTemple;
                        }
                        break;
                    case 63:
                    case 70:
                    case 75:
                        if(mapobjects[i].owner === "Red") {
                            markers[id].icon = redHollow;
                        } else if(mapobjects[i].owner === "Green") {
                            markers[id].icon = greenHollow;
                        } else if(mapobjects[i].owner === "Blue") {
                            markers[id].icon = blueHollow;
                        } else {
                            markers[id].icon = whiteHollow;
                        }
                        break;
                    case 64:
                    case 69:
                    case 74:
                        if(mapobjects[i].owner === "Red") {
                            markers[id].icon = redBauer;
                        } else if(mapobjects[i].owner === "Green") {
                            markers[id].icon = greenBauer;
                        } else if(mapobjects[i].owner === "Blue") {
                            markers[id].icon = blueBauer;
                        } else {
                            markers[id].icon = whiteBauer;
                        }
                        break;
                    case 65:
                    case 68:
                    case 73:
                        if(mapobjects[i].owner === "Red") {
                            markers[id].icon = redOrchard;
                        } else if(mapobjects[i].owner === "Green") {
                            markers[id].icon = greenOrchard;
                        } else if(mapobjects[i].owner === "Blue") {
                            markers[id].icon = blueOrchard;
                        } else {
                            markers[id].icon = whiteOrchard;
                        }
                        break;
                    case 66:
                    case 67:
                    case 72:
                        if(mapobjects[i].owner === "Red") {
                            markers[id].icon = redCarver;
                        } else if(mapobjects[i].owner === "Green") {
                            markers[id].icon = greenCarver;
                        } else if(mapobjects[i].owner === "Blue") {
                            markers[id].icon = blueCarver;
                        } else {
                            markers[id].icon = whiteCarver;
                        }
                        break;
                default:
                    break;
            }
            updateMarkers();
        }
    }
}

function updateMarkers() {
    for(var i=1; i<markers.length;i++) {
        if(owner[i].changed) {
            marker[i].setIcon(markers[i].icon);
            owner[i].changed = false;
        }
    }
}

function updateOwnerGuild(newguild,id) {
    if(owner[id].guild == newguild) {
        owner[id].changed = false;
        owner[id].guild = newguild;
    } else {
        marker[id].unbindPopup();
        owner[id].guild = newguild;
        var guilds = getData('https://api.guildwars2.com/v1/guild_details.json?guild_id='+newguild);
        marker[id].bindPopup('<p>Claimed by '+guilds.guild_name+' ['+guilds.tag+']</p>');
        owner[id].changed = true;
    }
}

function updateOwner(newowner, id) {
    if(owner[id].owner == newowner) {
        owner[id].changed = false;
        marker[id].unbindPopup();
        owner[id].guild = "0";
    } else {
       if(owner[id].owner != "Grey") {
           console.log("Marker " + id + ": " + markers[id].name + " wurde gedreht.\n Ursprünglicher Besitzer: "+owner[id].owner+ " -> neuer Besitzer: "+newowner);
       }
       owner[id].owner = newowner;
       owner[id].changed = true;
       marker[id].unbindPopup();
       owner[id].guild = "0";
    }
}

function unproject(coord) {
    return map.unproject(coord, map.getMaxZoom());
}

function onMapClick(e) {
    console.log("You clicked the map at " + map.project(e.latlng));
}

function newmatch() {
    if(newBordernames) {
        setBorderNames();
        var matchEnd = matchdata['end_time'];
        matchEndTimestamp = Math.round(new Date(matchEnd).getTime() / 1000);
        console.log("A new match just began.");
        newBordernames = false;
    }
}











initialise();
newmatch();
setScores();
paint();
$(function () {
    "use strict";
    var southWest, northEast;
    map = L.map("map", {
        minZoom: 0,
        maxZoom: 6,
        crs: L.CRS.Simple
    });
    southWest = unproject([0, 16384]);
    northEast = unproject([16384, 0]);
    map.setMaxBounds(new L.LatLngBounds(southWest, northEast));
    L.tileLayer("https://tiles.guildwars2.com/2/1/{z}/{x}/{y}.jpg", {
        minZoom: 0,
        maxZoom: 6,
        continuousWorld: true
    }).addTo(map);
    setMapMarkers();
    marker = [];
    for(var i=1; i<markers.length;i++) {  
        marker[i] = new L.marker(unproject(markers[i].coord), {
            title: markers[i].name,            
            icon: markers[i].icon
                    }).addTo(map);
    }
    map.on("click", onMapClick);
    map.setView(unproject([10500,11834]),0);
    setMarkersHolder();
});

eventlistener();
window.setInterval(function() {setScores();}, 1200000);
window.setInterval(function() {updateDatas();}, updatetime);
});